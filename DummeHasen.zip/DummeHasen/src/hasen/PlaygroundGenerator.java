package hasen;

import static hasen.BaseFrame.*;

import javax.swing.JFrame;


public class PlaygroundGenerator {
    

        
        public static void ResetFrame() {
            Frame.getContentPane().removeAll();
            Frame.revalidate();
            Frame.repaint();
            Frame.setSize(1000, 1000);
            Frame.setLayout(null);
            Frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            
            UseItem.setBounds(450, 850, 80, 80);
            NewGame.setBounds(400, 400, 200, 60);
            
            Frame.add(UseItem);
            Frame.add(NewGame);
            Frame.setVisible(true);
            
            GenerateVisualArray();
        }
}
