package hasen;

import static hasen.Main.*;
import static hasen.BaseFrame.*;
import java.io.BufferedReader;
import java.io.FileNotFoundException;

import java.io.FileReader;
import java.io.IOException;
import javax.swing.JFrame;


public class PlaygroundGenerator {
    

        public static void LoadLevel() throws FileNotFoundException, IOException {
            FileReader reader = new FileReader("Levels/Level1.dat");
            BufferedReader LevelLoader = new BufferedReader(reader);
            
            
            
            
            for(int i=0; i<20; i++) {
                for(int x=0; x<20; x++){
                Spielfeld[i][x]="X";
                }
            }
        }
        public static void ResetFrame() {
            Frame.getContentPane().removeAll();
            Frame.revalidate();
            Frame.repaint();
            Frame.setSize(1000, 1000);
            Frame.setLayout(null);
            Frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            
            UseItem.setBounds(450, 850, 80, 80);
            NewGame.setBounds(400, 400, 200, 60);
            
            Frame.add(UseItem);
            Frame.add(NewGame);
            Frame.setVisible(true);
            
            GenerateVisualArray();
        }
}
