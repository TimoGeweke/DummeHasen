package hasen;

import static hasen.Framework.*;
import static hasen.Main.Spielfeld;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class PlaygroundGenerator {
        
        public static void VisualizePlayground() {
        
        int XCoordinate = 40;
        int YCoordinate = 40;
        
        for(int i=0; i<Spielfeld.length; i++) {
            for(int x = 0; x<Spielfeld.length; x++) {
                
                if(Spielfeld[i][x].equals("B")){
                    ImageIcon icon = new ImageIcon("Ressources/Bunny.png");
                    JLabel label = new JLabel(icon);
                    Frame.add(label);
                    label.setBounds(XCoordinate, YCoordinate, 40, 40);
                }
                else if(Spielfeld[i][x].equals("F")){
                    ImageIcon icon = new ImageIcon("Ressources/Fox.png");
                    JLabel label = new JLabel(icon);
                    Frame.add(label);
                    label.setBounds(XCoordinate, YCoordinate, 40, 40);
                }
                else if(Spielfeld[i][x].equals("S")){
                    ImageIcon icon = new ImageIcon("Ressources/Stone.png");
                    JLabel label = new JLabel(icon);
                    Frame.add(label);
                    label.setBounds(XCoordinate, YCoordinate, 40, 40);
                }
                else {
                    ImageIcon icon = new ImageIcon("Ressources/Grass.png");
                    JLabel label = new JLabel(icon);
                    Frame.add(label);
                    label.setBounds(XCoordinate, YCoordinate, 40, 40);
                }
                XCoordinate = XCoordinate + 40;
            }
            YCoordinate = YCoordinate + 40;
            XCoordinate = 40;
        }
    }
}
