package hasen;

import static hasen.Main.*;
import static hasen.BaseFrame.*;
import java.io.BufferedReader;
import java.io.FileNotFoundException;

import java.io.FileReader;
import java.io.IOException;
import javax.swing.JFrame;


public class PlaygroundGenerator {
    

        public static void LoadLevel() throws FileNotFoundException, IOException {
            FileReader reader = new FileReader("Level" + LevelNumber + ".dat");
            BufferedReader LevelLoader = new BufferedReader(reader);
            
            String Line = LevelLoader.readLine();
            while(Line != null) {
                
            }
            
            for(int i=0; i<20; i++) {
                for(int x=0; x<20; x++){
                Spielfeld[i][x]="X";
                }
            }
        }
        public static void ResetFrame() {
            Frame.getContentPane().removeAll();
            Frame.revalidate();
            Frame.repaint();
            Frame.setSize(1000, 1000);
            Frame.setLayout(null);
            Frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            
            WalkRight.setBounds(130, 850, 80, 80);
            WalkLeft.setBounds(40, 850, 80, 80);
            WalkUp.setBounds(220, 850, 80, 80);
            WalkDown.setBounds(310, 850, 80, 80);
            UseItem.setBounds(450, 850, 80, 80);
            NewGame.setBounds(400, 400, 200, 60);
            
            Frame.add(WalkRight);
            Frame.add(WalkLeft);
            Frame.add(WalkUp);
            Frame.add(WalkDown);
            Frame.add(UseItem);
            Frame.add(NewGame);
            Frame.setVisible(true);
            
            GenerateVisualArray();
        }
}
