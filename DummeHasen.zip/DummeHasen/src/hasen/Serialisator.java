package hasen;

import static hasen.Main.*;
import java.io.BufferedReader;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Serialisator {
    
    public static void LoadLevel() throws FileNotFoundException, IOException {
            
        BufferedReader br=new BufferedReader (new FileReader ("fives.txt"));
        while(br.readLine()!=null){
            
        }
    }
}
