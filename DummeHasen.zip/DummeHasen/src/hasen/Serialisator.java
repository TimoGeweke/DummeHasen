package hasen;

import static hasen.Main.*;
import java.io.BufferedReader;
import java.io.File;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Serialisator {
    
    public static void LoadLevel() throws FileNotFoundException, IOException {
        
            
        BufferedReader br=new BufferedReader (new FileReader ("Levels/Level1.txt"));
        
        String line;
        while((line = br.readLine())!= null){
            Scanner sc = new Scanner(new File("Levels/Level1.txt")).useDelimiter(",//*");
            while(sc.hasNextInt()) {
                for(int i = 0; i<Spielfeld.length; i++) {
                    for(int x = 0; x<Spielfeld.length; x++) {
                        Spielfeld[i][x] = sc.nextInt();
                    }
                }
            }    
        }
    }
    
    
    public static void PrintArray() {
        for(int i = 0; i<Spielfeld.length; i++) {
            for(int x = 0; x<Spielfeld.length; x++) {
                System.out.print(Spielfeld[i][x]);
            }
            System.out.println();
        }
    }
}
