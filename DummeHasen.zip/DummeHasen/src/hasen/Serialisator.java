package hasen;

import static hasen.Main.*;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Scanner;

public class Serialisator {
    
    public static void LoadLevel() throws FileNotFoundException, IOException {
        
            
        List<String> FileLines = Files.readAllLines(Paths.get("Levels/Level" + LevelNumber + ".txt"));
        Scanner sc = new Scanner(new File("Levels/Level1.txt"));
        
        for (int i = FileLines.size() - 1; i >= 0; i--) {
        if (FileLines.get(i).isEmpty()) {
            FileLines.remove(i);
        }
    }
        
        Playground = new String[FileLines.size()][];
        
        for(int i = 0; i < FileLines.size(); i++) {
            String[] splitLine = FileLines.get(i).split("\\s");
            
            Playground[i] = new String[splitLine.length];
            for (int x = 0; x < splitLine.length; x++) {
            Playground[i][x] = splitLine[x];
            }
        } 
    }
    
    
    public static void PrintArray() {
        for(int i = 0; i<Playground.length; i++) {
            for(int x = 0; x<Playground.length; x++) {
                System.out.print(Playground[i][x]);
            }
            System.out.println();
        }
    }
}
