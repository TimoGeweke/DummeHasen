package hasen;

import static hasen.Main.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;



public class Framework {
    
    static JFrame Frame = new JFrame(" ");
    static JButton UseItem = new JButton("Danger: Useless Button!!!");
    static JButton NewGame = new JButton("You lost! New Game?");
    
    public static void GenerateFrame() {
        
    
        Frame.setSize(900, 1000);
        Frame.setLayout(null);
        Frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        Frame.setVisible(true);    
    }
    
    public static void SetupPlayground() {
        UseItem.setBounds(450, 850, 200, 80);
        UseItem.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                
            } 
        });
        NewGame.setBounds(400, 400, 200, 60);
        NewGame.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                Frame.getContentPane().removeAll();

                try {
                    NewGame();
                } catch (IOException ex) {
                    Logger.getLogger(Framework.class.getName()).log(Level.SEVERE, null, ex);
                }
                NewGame.setVisible(false);
            } 
        });
        Frame.add(UseItem);
        Frame.add(NewGame);                
    }
    
    public static void ResetFrame() {
        Frame.getContentPane().removeAll();
        Frame.revalidate();
        Frame.repaint();
        Frame.setSize(1000, 1000);
        Frame.setLayout(null);
        Frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
