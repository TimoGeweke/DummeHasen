package hasen;

import static hasen.Main.*;
import static hasen.BunnyAPI.*;
import static hasen.FoxAPI.*;
import static hasen.PlaygroundGenerator.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;



public class BaseFrame {
    
    static JFrame Frame = new JFrame(" ");
    static JButton WalkRight = new JButton("RIGHT");
    static JButton WalkLeft = new JButton("LEFT");
    static JButton WalkUp = new JButton("UP");
    static JButton WalkDown = new JButton("DOWN");
    static JButton UseItem = new JButton("ITEM");
    static JButton NewGame = new JButton("You lost! New Game?");
    
    public static void GenerateFrame() {
        
    
        Frame.setSize(1000, 1000);
        Frame.setLayout(null);
        Frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        WalkLeft.setBounds(40, 850, 80, 80);
        WalkLeft.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                MoveLeft();
            }  
        }); 
        WalkRight.setBounds(130, 850, 80, 80);
        WalkRight.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                MoveRight();
            } 
        });
        WalkUp.setBounds(220, 850, 80, 80);
        WalkUp.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                MoveUp();
            } 
        });
        WalkDown.setBounds(310, 850, 80, 80);
        WalkDown.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                MoveDown();
            } 
        });
        
        
        UseItem.setBounds(450, 850, 80, 80);
        UseItem.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                
            } 
        });
        NewGame.setBounds(400, 400, 200, 60);
        NewGame.setVisible(false);
        NewGame.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                Frame.getContentPane().removeAll();
        
                NewGame();
            
                NewGame.setVisible(false);
     
            } 
        });
        
         
        
        Frame.add(WalkRight);
        Frame.add(WalkLeft);
        Frame.add(WalkUp);
        Frame.add(WalkDown);
        Frame.add(UseItem);
        Frame.add(NewGame);
        Frame.setVisible(true);
                
    }
    
    
    public static void GenerateVisualArray() {
        
        int XCoordinate = 40;
        int YCoordinate = 40;
        
        for(int i=0; i<Spielfeld.length; i++) {
            for(int x = 0; x<Spielfeld.length; x++) {
                
                if(Spielfeld[i][x].equals("Bunny")){
                    ImageIcon icon = new ImageIcon("Bunny.png");
                    JLabel label = new JLabel(icon);
                    Frame.add(label);
                    label.setBounds(XCoordinate, YCoordinate, 40, 40);
                }
                else if(Spielfeld[i][x].equals("Fox")){
                    ImageIcon icon = new ImageIcon("Fox.png");
                    JLabel label = new JLabel(icon);
                    Frame.add(label);
                    label.setBounds(XCoordinate, YCoordinate, 40, 40);
                }
                else {
                    ImageIcon icon = new ImageIcon("weed.png");
                    JLabel label = new JLabel(icon);
                    Frame.add(label);
                    label.setBounds(XCoordinate, YCoordinate, 40, 40);
                }
                XCoordinate = XCoordinate + 40;
            }
            YCoordinate = YCoordinate + 40;
            XCoordinate = 40;
        }
    }

    private static void addText(String Spielfeld, int XCoordinate, int YCoordinate, int w, int h) {

        
        
        
    }

    public BaseFrame() {
    }
}
