package hasen;

import static hasen.Main.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;



public class BaseFrame {
    
    static JFrame Frame = new JFrame(" ");
    static JButton WalkRight = new JButton("RIGHT");
    static JButton WalkLeft = new JButton("LEFT");
    static JButton WalkUp = new JButton("UP");
    static JButton WalkDown = new JButton("DOWN");
    static JButton UseItem = new JButton("ITEM");
    static JButton NewGame = new JButton("You lost! New Game?");
    
    public static void GenerateFrame() {
        
    
        Frame.setSize(1000, 1000);
        Frame.setLayout(null);
        Frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        
        UseItem.setBounds(450, 850, 80, 80);
        UseItem.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                
            } 
        });
        NewGame.setBounds(400, 400, 200, 60);
        NewGame.setVisible(false);
        NewGame.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                Frame.getContentPane().removeAll();
        
                try {
                    NewGame();
                } catch (IOException ex) {
                    Logger.getLogger(BaseFrame.class.getName()).log(Level.SEVERE, null, ex);
                }
            
                NewGame.setVisible(false);
     
            } 
        });
        Frame.add(UseItem);
        Frame.add(NewGame);
        Frame.setVisible(true);    
    }
    
    public static void GenerateVisualArray() {
        
        int XCoordinate = 40;
        int YCoordinate = 40;
        
        for(int i=0; i<Spielfeld.length; i++) {
            for(int x = 0; x<Spielfeld.length; x++) {
                
                if(Spielfeld[i][x] == 1){
                    ImageIcon icon = new ImageIcon("Ressoures/Bunny.png");
                    JLabel label = new JLabel(icon);
                    Frame.add(label);
                    label.setBounds(XCoordinate, YCoordinate, 40, 40);
                }
                else if(Spielfeld[i][x] == 2){
                    ImageIcon icon = new ImageIcon("Ressoures/Fox.png");
                    JLabel label = new JLabel(icon);
                    Frame.add(label);
                    label.setBounds(XCoordinate, YCoordinate, 40, 40);
                }
                else {
                    ImageIcon icon = new ImageIcon("Ressoures/weed.png");
                    JLabel label = new JLabel(icon);
                    Frame.add(label);
                    label.setBounds(XCoordinate, YCoordinate, 40, 40);
                }
                XCoordinate = XCoordinate + 40;
            }
            YCoordinate = YCoordinate + 40;
            XCoordinate = 40;
        }
    }
}
