
package hasen;

import static hasen.Main.*;
import static hasen.BunnyKI.*;

public class FoxKI {
    
    public static void MoveFox(){
        
        if(BPosY > FPosY){
           Spielfeld[FPosY][FPosX].equals("B");
           FPosY++;
            }
    else if(BPosY < FPosY){
            Spielfeld[FPosY][FPosX] = "0";
            FPosY--;
            TestForBunny();
            }         
    else if(BPosY == FPosY){
         if(BPosX < FPosX){
            Spielfeld[FPosY][FPosX].equals("0");
            FPosX--;
            TestForBunny();
            }
    else if(BPosX > FPosX){
            Spielfeld[FPosY][FPosX].equals("0");
            FPosX++;
            TestForBunny();
            }
        }        
    }
    
    private static void TestForBunny(){
        if(Spielfeld[FPosY][FPosX].equals("B")){
                Spielfeld[FPosY][FPosX] = "F";
                GameOver();
            }
            else{
                Spielfeld[FPosY][FPosX] = "F";
        }
    }
}
