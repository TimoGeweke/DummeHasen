
package hasen;

import static hasen.Main.*;
import static hasen.Framework.*;
import static hasen.PlaygroundGenerator.*;

public class FoxKI {
    
    private static int TestPosX = FPosX;
    private static int TestPosY = FPosY;
    private static int TurnsNeeded = 0;
    private static int MinimumTurns = 99999;
    private static boolean MoveSuccess = false;
    private static boolean IsFirstMove = true;
    
    
    private static int TestMove;
    private static int FirstTestMove;
    private static int ActualMove;
    // 0 = X +
    // 1 = X -
    // 2 = Y +
    // 3 = Y -
    
    public static void MoveFox(){
        
        MinimumTurns = 99999;
        
        for(int TestTurns = 0; TestTurns < 9999; TestTurns++) {
            
            TurnsNeeded = 0;
            do{
                do{
                    TestMove = (int)(Math.random() * 4);
                    DoTestMove();
                }while(!MoveSuccess);
                
                if(IsFirstMove) {
                    FirstTestMove = TestMove;
                    IsFirstMove = false;
                }
                
                TurnsNeeded++;
                MoveSuccess = false;
                
            }while(TestPosX != BPosX && TestPosY != BPosY);
            IsFirstMove = true;
            TestPosX = FPosX;
            TestPosY = FPosY;
            
            if(TurnsNeeded < MinimumTurns){
                MinimumTurns = TurnsNeeded;
                ActualMove = FirstTestMove;
                
                System.out.println("TestMove: " + TestMove);
                System.out.println("MinimumTurns: " + MinimumTurns);
                System.out.println("ActualMove: " + ActualMove);
                
            }
            
        }
        ExecuteMove();
        TestForBunny();
    }
        
    private static void TestForBunny(){
        if(Playground[FPosY][FPosX].equals("B")){
                Playground[FPosY][FPosX] = "F";
                GameOver();
            }
            else{
                Playground[FPosY][FPosX] = "F";
        }
    }
    
    private static void DoTestMove() {
        if(TestMove == 0) {
            TestPosX++;
            if(TestPosX == 20){
                TestPosX--;
            }
            else if(Playground[TestPosY][TestPosX].equals("S")) {
                TestPosX--;
            }
            else{
                MoveSuccess = true;
            }
        }
        else if(TestMove == 1) {
            TestPosX--;
            if(TestPosX == -1){
                TestPosX++;
            }
            else if(Playground[TestPosY][TestPosX].equals("S")){
                TestPosX++;
            }
            else{
                MoveSuccess = true;
            }
        } 
        else if(TestMove == 2) {
            TestPosY++;
            if(TestPosY == 20){
                TestPosY--;
            }
            else if(Playground[TestPosY][TestPosX].equals("S")){
                TestPosY--;
            }
            else{
                MoveSuccess = true;
            }
        }
        else if(TestMove == 3) {
            TestPosY--;
            if(TestPosY == -1){
                TestPosY++;
            }
            else if(Playground[TestPosY][TestPosX].equals("S")){
                TestPosY++;
            }
            else{
                MoveSuccess = true;
            }
        }
    }
    
    private static void ExecuteMove(){
        if(ActualMove == 0) {
            Playground[FPosY][FPosX] = "0";
            FPosX++;
            Playground[FPosY][FPosX] = "F";
        }
        else if(ActualMove == 1) {
            Playground[FPosY][FPosX] = "0";
            FPosX--;
            Playground[FPosY][FPosX] = "F";
        }
        else if(ActualMove == 2) {
            Playground[FPosY][FPosX] = "0";
            FPosY++;
            Playground[FPosY][FPosX] = "F";
        }
        else if(ActualMove == 3) {
            Playground[FPosY][FPosX] = "0";
            FPosY--;
            Playground[FPosY][FPosX] = "F";
        }
        ResetFrame();
        VisualizePlayground();
    }
}
