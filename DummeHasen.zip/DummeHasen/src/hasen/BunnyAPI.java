package hasen;

import static hasen.Main.*;
import static hasen.PlaygroundGenerator.*;
import static hasen.FoxAPI.*;

public class BunnyAPI {
    
     /* int BPosX = (int) Math.random()*19;
        int BPosY = (int) Math.random()*19;*/
        static int BPosX = 10;
        static int BPosY = 2;
    
        public static void PlaceBunny() {
                       
        
        Spielfeld[BPosY][BPosX] = "Bunny";
    }
        
        public static void MoveUp() {
                      
                   
            if(BPosY == 0) {
                Spielfeld[BPosY][BPosX] = "X";
                BPosY = 19;
                FoxTest();
        }
            else {
                Spielfeld[BPosY][BPosX] = "X";
                BPosY --;
                FoxTest();
            }
        }
        public static void MoveDown() {
            if(BPosY == 19) {
                Spielfeld[BPosY][BPosX] = "X";
                BPosY = 0;
                FoxTest();
        }
            else {
                Spielfeld[BPosY][BPosX] = "X";
                BPosY ++;
                FoxTest();
            }   
        }
        public static void MoveLeft() {
            if(BPosX == 0) {
                Spielfeld[BPosY][BPosX] = "X";
                BPosX= 19;
                FoxTest();
        }
            else {
                Spielfeld[BPosY][BPosX] = "X";
                BPosX --;
                FoxTest();
            }   
        }public static void MoveRight() {
            if(BPosX == 19) {
                Spielfeld[BPosY][BPosX] = "X";
                BPosX = 0;
                FoxTest();
        }
            else {
                Spielfeld[BPosY][BPosX] = "X";
                BPosX ++;
                FoxTest();
            }   
        }
        
        private static void FoxTest(){
            if(Spielfeld[BPosY][BPosX].equalsIgnoreCase("Fox")) {
                Spielfeld[BPosY][BPosX] = "Fox";
                GameOver();
            }
            else{
                Spielfeld[BPosY][BPosX] = "Bunny";
                MoveFox();
                ResetFrame();
            }
        }
}