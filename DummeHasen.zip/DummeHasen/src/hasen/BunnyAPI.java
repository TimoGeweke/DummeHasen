package hasen;

import static hasen.Main.*;
import static hasen.PlaygroundGenerator.*;
import static hasen.FoxAPI.*;
import java.awt.event.KeyEvent;

public class BunnyAPI {
    
        static int BPosX;
        static int BPosY;
    
        public static void PlaceBunny() {
                       
        
        Spielfeld[BPosY][BPosX] = "Bunny";
    }
        
        public static void MoveUp(KeyEvent e) {
                      
            int key = e.getKeyCode();
                   
            if(key == KeyEvent.VK_UP) {
                if(BPosY == 0) {
                Spielfeld[BPosY][BPosX] = "X";
                BPosY = 19;
        }
            else {
                Spielfeld[BPosY][BPosX] = "X";
                BPosY --;
            }
            }
        }
        public static void MoveDown(KeyEvent e) {
            
            int key = e.getKeyCode();
            
            if(key == KeyEvent.VK_DOWN){
                if(BPosY == 19) {
                Spielfeld[BPosY][BPosX] = "X";
                BPosY = 0;
        }
            else {
                Spielfeld[BPosY][BPosX] = "X";
                BPosY ++;
                }
            }
        }
        public static void MoveLeft(KeyEvent e) {
            
            int key = e.getKeyCode();
            
            if(key == KeyEvent.VK_LEFT) {
                if(BPosX == 0) {
                Spielfeld[BPosY][BPosX] = "X";
                BPosX= 19;
        }
            else {
                Spielfeld[BPosY][BPosX] = "X";
                BPosX --;
                }
            }   
        }
        public static void MoveRight(KeyEvent e) {
            
            int key = e.getKeyCode();
            
            if(key == KeyEvent.VK_RIGHT) {
                if(BPosX == 19) {
                Spielfeld[BPosY][BPosX] = "X";
                BPosX = 0;
        }
            else {
                Spielfeld[BPosY][BPosX] = "X";
                BPosX ++;
                }
            }
        }
        
}