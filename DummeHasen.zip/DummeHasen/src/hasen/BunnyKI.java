package hasen;

import static hasen.Main.*;
import java.awt.event.KeyEvent;

public class BunnyKI {
    
    

        public static void MoveUp(KeyEvent e) {
                      
            int key = e.getKeyCode();
                   
            if(key == KeyEvent.VK_UP) {
                if(BPosY == 0) {
                Playground[BPosY][BPosX] = "B";
                BPosY = 19;
        }
            else {
                Playground[BPosY][BPosX] = "0";
                BPosY --;
                }
            }
        }
        public static void MoveDown(KeyEvent e) {
            
            int key = e.getKeyCode();
            
            if(key == KeyEvent.VK_DOWN){
                if(BPosY == 19) {
                Playground[BPosY][BPosX] = "0";
                BPosY = 0;
        }
            else {
                Playground[BPosY][BPosX] = "0";
                BPosY ++;
                }
            }
        }
        public static void MoveLeft(KeyEvent e) {
            
            int key = e.getKeyCode();
            
            if(key == KeyEvent.VK_LEFT) {
                if(BPosX == 0) {
                Playground[BPosY][BPosX] = "0";
                BPosX= 19;
        }
            else {
                Playground[BPosY][BPosX] = "0";
                BPosX --;
                }
            }   
        }
        public static void MoveRight(KeyEvent e) {
            
            int key = e.getKeyCode();
            
            if(key == KeyEvent.VK_RIGHT) {
                if(BPosX == 19) {
                Playground[BPosY][BPosX] = "0";
                BPosX = 0;
        }
            else {
                Playground[BPosY][BPosX] = "0";
                BPosX ++;
                }
            }
        }
}