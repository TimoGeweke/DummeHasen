package hasen;

import static hasen.BunnyAPI.*;
import static hasen.BaseFrame.*;
import static hasen.PlaygroundGenerator.*;
import static hasen.FoxAPI.*;
import static hasen.Serialisator.*;

import java.io.FileNotFoundException;


import java.io.IOException;
import javax.swing.*;

public class Main {
    
    static int[][] Spielfeld = new int[20][20];
    
    static int LevelNumber = 1;
   

    public static void main(String[] args) throws IOException{
        
        
        LoadLevel();
         GenerateVisualArray();
        GenerateFrame();
       
        
        PrintArray();
        
    }
    public static void NewGame() throws FileNotFoundException, IOException{
        
        
            
        Frame.getContentPane().removeAll();
        
        LoadLevel();
        ResetFrame();
        GenerateVisualArray();
        
        Frame.remove(NewGame);
        
    }
    
    public static void GameOver(){
        NewGame.setVisible(true);
        
        
    }
}
