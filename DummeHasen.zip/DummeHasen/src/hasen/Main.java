package hasen;

import static hasen.BunnyAPI.*;
import static hasen.BaseFrame.*;
import static hasen.PlaygroundGenerator.*;
import static hasen.FoxAPI.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;


import java.io.IOException;

public class Main {
    
    static String[][] Spielfeld = new String[20][20];
    
    static int LevelNumber = 1;
   

    public static void main(String[] args) throws IOException{
        
        
        LoadLevel();
        PlaceBunny();
        PlaceFox();
        GenerateFrame();
        GenerateVisualArray();
        
    }
    public static void NewGame() throws FileNotFoundException, IOException{
        
        FPosX = 15;
        FPosY = 15;
            
        BPosX = 10;
        BPosY = 2;
            
        Frame.getContentPane().removeAll();
        
        LoadLevel();
        PlaceBunny();
        PlaceFox();
        ResetFrame();
        GenerateVisualArray();
        
        Frame.remove(NewGame);
        
    }
    
    public static void GameOver(){
        NewGame.setVisible(true);
        
        
    }
}
