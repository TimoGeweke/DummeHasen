package hasen;

import static hasen.Framework.*;
import static hasen.PlaygroundGenerator.*;
import static hasen.Serialisator.*;
import static hasen.MainMenu.*;

import java.io.FileNotFoundException;


import java.io.IOException;

public class Main {
    
    static String[][] Spielfeld;
    
    static int LevelNumber = 1;
    
    static int BPosX;
    static int BPosY;
    
    static int FPosX;
    static int FPosY;
   

    public static void main(String[] args) throws IOException{
        
        GenerateFrame();
        CreateMainMenu();
        
    }
    public static void NewGame() throws FileNotFoundException, IOException{
        
        Frame.getContentPane().removeAll();
        
        LoadLevel();
        ResetFrame();
        SetupPlayground();
        VisualizePlayground();
        
        Frame.remove(NewGame);
        
    }
    
    public static void GameOver(){
        NewGame.setVisible(true);
        
    }
}
