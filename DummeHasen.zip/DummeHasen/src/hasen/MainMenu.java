package hasen;

import static hasen.Framework.*;
import static hasen.Main.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.*;

public class MainMenu {
    
    static JButton StartGame = new JButton("Start the selected Level");
    static JButton LoadLevel = new JButton("Load a different Level");
    static JButton EndGame = new JButton("End the Game");
    
    public static void CreateMainMenu() {
        StartGame.setBounds(100, 300, 650, 100);
        StartGame.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                try {
                    GetLevelMeta();
                    NewGame();
                } catch (IOException ex) {
                    Logger.getLogger(MainMenu.class.getName()).log(Level.SEVERE, null, ex);
                }
            } 
        });
        
        LoadLevel.setBounds(100, 500, 550, 100);
        LoadLevel.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
                
            } 
        });
        
        EndGame.setBounds(100, 700, 650, 100);
        EndGame.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae) {
            } 
        });
        
        Frame.add(StartGame);
        Frame.add(LoadLevel);
        Frame.add(EndGame);
    }
    
    public static void GetLevelMeta(){
        
        if(LevelNumber == 1) {
            BPosX = 1;
            BPosY = 1;
            FPosX = 16;
            FPosY = 4;
        }
    }
}
