
package hasen;

import static hasen.Main.*;
import static hasen.BunnyAPI.*;

public class FoxAPI {
    static int FPosX = 15;
    static int FPosY = 15;
    
    public static void PlaceFox(){
    
        Spielfeld[FPosY][FPosX] = "Fox";
       
    }
    
    public static void MoveFox(){
        
        if(BPosY > FPosY){
           Spielfeld[FPosY][FPosX] = "X";
           FPosY++;
           if(Spielfeld[FPosY][FPosX].equals("Bunny")){
                Spielfeld[FPosY][FPosX] = "Fox";
                GameOver();
        }
          else{
                Spielfeld[FPosY][FPosX] = "Fox";
            }  
        }
        
    else if(BPosY < FPosY){
            Spielfeld[FPosY][FPosX] = "X";
            FPosY--;
            if(Spielfeld[FPosY][FPosX].equals("Bunny")){
                Spielfeld[FPosY][FPosX] = "Fox";
                GameOver();
        }
            else{
                Spielfeld[FPosY][FPosX] = "Fox";
            } 
    }         
    else if(BPosY == FPosY){
         
         if(BPosX < FPosX){
            Spielfeld[FPosY][FPosX] = "X";
            FPosX--;
            if(Spielfeld[FPosY][FPosX].equals("Bunny")){
                Spielfeld[FPosY][FPosX] = "Fox";
                GameOver();
        }
            else{
                Spielfeld[FPosY][FPosX] = "Fox";
            }
        }
         else if(BPosX > FPosX){
                 Spielfeld[FPosY][FPosX] = "X";
                 FPosX++;
                 if(Spielfeld[FPosY][FPosX].equals("Bunny")){
                    GameOver();
                    Spielfeld[FPosY][FPosX] = "Fox";
        }
                 else {
                Spielfeld[FPosY][FPosX] = "Fox";
                } 
            }
         else if(BPosX == FPosX){
             GameOver();
            }
        }        
    }
}
