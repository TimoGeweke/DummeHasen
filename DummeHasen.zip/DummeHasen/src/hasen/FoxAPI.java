
package hasen;

import static hasen.Main.*;
import static hasen.BunnyAPI.*;

public class FoxAPI {
    static int FPosX = 15;
    static int FPosY = 15;
    
    public static void MoveFox(){
        
        if(BPosY > FPosY){
           Spielfeld[FPosY][FPosX] = 0;
           FPosY++;
           if(Spielfeld[FPosY][FPosX] == 1){
                Spielfeld[FPosY][FPosX] = 2;
                GameOver();
        }
          else{
                Spielfeld[FPosY][FPosX] = 2;
            }  
        }
        
    else if(BPosY < FPosY){
            Spielfeld[FPosY][FPosX] = 0;
            FPosY--;
            if(Spielfeld[FPosY][FPosX] == 1){
                Spielfeld[FPosY][FPosX] = 2;
                GameOver();
        }
            else{
                Spielfeld[FPosY][FPosX] = 2;
            } 
    }         
    else if(BPosY == FPosY){
         
         if(BPosX < FPosX){
            Spielfeld[FPosY][FPosX] = 0;
            FPosX--;
            if(Spielfeld[FPosY][FPosX] == 1){
                Spielfeld[FPosY][FPosX] = 2;
                GameOver();
        }
            else{
                Spielfeld[FPosY][FPosX] = 2;
            }
        }
         else if(BPosX > FPosX){
                 Spielfeld[FPosY][FPosX] = 0;
                 FPosX++;
                 if(Spielfeld[FPosY][FPosX] == 1){
                    GameOver();
                    Spielfeld[FPosY][FPosX] = 2;
        }
                 else {
                Spielfeld[FPosY][FPosX] = 2;
                } 
            }
         else if(BPosX == FPosX){
             GameOver();
            }
        }        
    }
}
